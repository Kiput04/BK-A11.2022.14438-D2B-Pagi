<x-layouts.admin>
    <div class="p-6 max-w-lg mx-auto">
        <h1 class="text-2xl font-bold mb-6">Tambah Tipe Tiket</h1>

        <form action="{{ route('admin.ticket-types.store') }}" method="POST" class="space-y-4">
            @csrf
            <div>
                <label class="label">Nama Tipe Tiket</label>
                <input type="text" name="nama" value="{{ old('nama') }}" class="input input-bordered w-full" required>
                @error('nama')
                    <span class="text-sm text-red-500">{{ $message }}</span>
                @enderror
            </div>
            <div class="flex gap-2">
                <a href="{{ route('admin.ticket-types.index') }}" class="btn btn-secondary">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</x-layouts.admin>