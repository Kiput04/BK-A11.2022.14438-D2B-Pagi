<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TicketType;

class TicketTypeController extends Controller
{
    public function index()
    {
        $types = TicketType::orderBy('nama_tipe_tiket')->get();
        return view('ticket_type.index', compact('types'));
    }

    public function create()
    {
        return view('admin.ticket-types.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|unique:ticket_types,nama',
        ]);

        TicketType::create($validated);

        return redirect()->route('admin.ticket-types.index')
            ->with('success', 'Tipe tiket berhasil ditambahkan.');
    }

    public function edit(TicketType $ticketType)
    {
        return view('admin.ticket-types.edit', compact('ticketType'));
    }

    public function update(Request $request, TicketType $ticketType)
    {
        $validated = $request->validate([
            'nama' => 'required|string|unique:ticket_types,nama,' . $ticketType->id,
        ]);

        $ticketType->update($validated);

        return redirect()->route('admin.ticket-types.index')
            ->with('success', 'Tipe tiket berhasil diperbarui.');
    }

    public function destroy(TicketType $ticketType)
    {
        $ticketType->delete();
        return redirect()->route('admin.ticket-types.index')
            ->with('success', 'Tipe tiket berhasil dihapus.');
    }
}