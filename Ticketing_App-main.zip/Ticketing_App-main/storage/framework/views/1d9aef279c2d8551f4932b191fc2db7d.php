

<?php $__env->startSection('content'); ?>
<h3>Manajemen Tipe Tiket</h3>

<a href="<?php echo e(route('admin.ticket-types.create')); ?>">Tambah Tipe Tiket</a>

<table border="1" cellpadding="10">
    <tr>
        <th>No</th>
        <th>Nama Tipe Tiket</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $ticketTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($item->nama_tipe_tiket); ?></td>
        <td>
            <a href="<?php echo e(route('admin.ticket-types.edit', $item->id)); ?>">Edit</a>

            <form action="<?php echo e(route('admin.ticket-types.destroy', $item->id)); ?>"
                  method="POST" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit">Hapus</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Semester 7\Ticketing_App-main\resources\views/admin/ticket-types/index.blade.php ENDPATH**/ ?>