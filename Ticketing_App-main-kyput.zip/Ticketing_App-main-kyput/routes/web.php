<?php

    use Illuminate\Support\Facades\Route;
    use App\Http\Controllers\ProfileController;

    // Admin Controllers
    use App\Http\Controllers\Admin\DashboardController;
    use App\Http\Controllers\Admin\CategoryController;
    use App\Http\Controllers\Admin\EventController;
    use App\Http\Controllers\Admin\TiketController;
    use App\Http\Controllers\Admin\TicketTypeController;
    use App\Http\Controllers\Admin\HistoriesController;
    use App\Http\Controllers\Admin\PaymentTypeController;

    // User Controllers
    use App\Http\Controllers\User\HomeController;
    use App\Http\Controllers\User\EventController as UserEventController;

    // -----------------------
    // Homepage (Guest / User)
    // -----------------------
    Route::get('/', [HomeController::class, 'index'])->name('home');

    // -----------------------
    // Dashboard Redirect
    // -----------------------
    Route::get('/dashboard', function () {
        return redirect('/admin');
    })->middleware(['auth'])->name('dashboard');

    // -----------------------
    // Routes Protected by Auth
    // -----------------------
    Route::middleware(['auth'])->group(function () {

        // Profile Routes
        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

        // -----------------------
        // Admin Routes
        // -----------------------
        Route::middleware('admin')
            ->prefix('admin')
            ->name('admin.')
            ->group(function () {

                // Admin Dashboard
                Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
                Route::resource('ticket-type', TicketTypeController::class);

                // Resource Controllers
                Route::resource('categories', CategoryController::class);
                Route::resource('events', EventController::class);
                Route::resource('tickets', TiketController::class);
                Route::resource('ticket-types', TicketTypeController::class); // <--- Ticket Types
                // Payment Type
                Route::resource('payment-types',PaymentTypeController::class);

                // Histories
                Route::get('histories', [HistoriesController::class, 'index'])->name('histories.index');
                Route::get('histories/{id}', [HistoriesController::class, 'show'])->name('histories.show');
            });

        // Detail Event (User)
        Route::get('/events/{event}', [UserEventController::class, 'show'])->name('events.show');
    });

    // -----------------------
    // Auth Routes (login, register, etc.)
    // -----------------------
    require __DIR__.'/auth.php';