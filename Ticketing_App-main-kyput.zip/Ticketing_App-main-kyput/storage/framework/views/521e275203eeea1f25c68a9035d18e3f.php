<ul class="menu w-full gap-1 px-2">
    <!-- Dashboard -->
    <li class="<?php echo e(request()->routeIs('admin.dashboard') ? 'bg-gray-200 rounded-lg' : ''); ?>">
        <a href="<?php echo e(route('admin.dashboard')); ?>"
           class="is-drawer-close:tooltip is-drawer-close:tooltip-right"
           data-tip="Dashboard">
            <span class="is-drawer-close:hidden">Dashboard</span>
        </a>
    </li>

    <!-- Kategori -->
    <li class="<?php echo e(request()->routeIs('admin.categories.*') ? 'bg-gray-200 rounded-lg' : ''); ?>">
        <a href="<?php echo e(route('admin.categories.index')); ?>"
           class="is-drawer-close:tooltip is-drawer-close:tooltip-right"
           data-tip="Kategori">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4h6v6H4zm10 0h6v6h-6zM4 14h6v6H4zm10 3a3 3 0 1 0 6 0a3 3 0 1 0-6 0" />
            </svg>
            <span class="is-drawer-close:hidden">Manajemen Kategori</span>
        </a>
    </li>

    <!-- Event -->
    <li class="<?php echo e(request()->routeIs('admin.events.*') ? 'bg-gray-200 rounded-lg' : ''); ?>">
        <a href="<?php echo e(route('admin.events.index')); ?>"
           class="is-drawer-close:tooltip is-drawer-close:tooltip-right"
           data-tip="Event">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5h14a2 2 0 0 1 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3a2 2 0 0 0 0-4V7a2 2 0 0 1 2-2" />
            </svg>
            <span class="is-drawer-close:hidden">Manajemen Event</span>
        </a>
    </li>

    <!-- Histories -->
    <li class="<?php echo e(request()->routeIs('admin.histories.*') ? 'bg-gray-200 rounded-lg' : ''); ?>">
        <a href="<?php echo e(route('admin.histories.index')); ?>"
           class="is-drawer-close:tooltip is-drawer-close:tooltip-right"
           data-tip="History">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
            <span class="is-drawer-close:hidden">History Pembelian</span>
        </a>
    </li>

    <!-- Ticket Types -->
    <li class="<?php echo e(request()->routeIs('admin.ticket-types.*') ? 'bg-gray-200 rounded-lg' : ''); ?>">
        <a href="<?php echo e(route('admin.ticket-types.index')); ?>"
           class="is-drawer-close:tooltip is-drawer-close:tooltip-right"
           data-tip="Tipe Tiket">
            <!-- icon tiket -->
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                      d="M4 8h16v8H4z M4 8l2-4h12l2 4 M4 16v2h16v-2" />
            </svg>
            <span class="is-drawer-close:hidden">Manajemen Tipe Tiket</span>
        </a>
    </li>

    <!-- Payment Type -->
    <li class="<?php echo e(request()->routeIs('admin.payment-types.*') ? 'bg-gray-200 rounded-lg' : ''); ?>">
        <a href="<?php echo e(route('admin.payment-types.index')); ?>"
           class="is-drawer-close:tooltip is-drawer-close:tooltip-right"
           data-tip="Tipe Tiket">
            <!-- icon tiket -->
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                      d="M4 8h16v8H4z M4 8l2-4h12l2 4 M4 16v2h16v-2" />
            </svg>
            <span class="is-drawer-close:hidden">Tipe Pembayaran</span>
        </a>
    </li>

</ul><?php /**PATH D:\Semester 7\Bimbingan Karir\Tugas Ticketing app\Ticketing_App-main\resources\views/components/admin/sidebar.blade.php ENDPATH**/ ?>