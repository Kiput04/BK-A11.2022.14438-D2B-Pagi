<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="hero bg-blue-900 min-h-screen">
        <div class="hero-content text-center text-white">
            <div class="max-w-4xl">
                <h1 class="text-5xl font-bold">Hi, Amankan Tiketmu yuk.</h1>
                <p class="py-6">
                    BengTix: Beli tiket, auto asik.
                </p>
            </div>
        </div>
    </div>

    <section class="max-w-7xl mx-auto py-12 px-6">
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-2xl font-black uppercase italic">Event</h2>
            <div class="flex gap-2">
                <a href="<?php echo e(route('home')); ?>">
                    <?php if (isset($component)) { $__componentOriginale3f30a12d951a73db04606714aa2ab07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3f30a12d951a73db04606714aa2ab07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.category-pill','data' => ['label' => 'Semua','active' => !request('kategori')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.category-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Semua'),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(!request('kategori'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3f30a12d951a73db04606714aa2ab07)): ?>
<?php $attributes = $__attributesOriginale3f30a12d951a73db04606714aa2ab07; ?>
<?php unset($__attributesOriginale3f30a12d951a73db04606714aa2ab07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3f30a12d951a73db04606714aa2ab07)): ?>
<?php $component = $__componentOriginale3f30a12d951a73db04606714aa2ab07; ?>
<?php unset($__componentOriginale3f30a12d951a73db04606714aa2ab07); ?>
<?php endif; ?>
                </a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('home', ['kategori' => $kategori->id])); ?>">
                    <?php if (isset($component)) { $__componentOriginale3f30a12d951a73db04606714aa2ab07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3f30a12d951a73db04606714aa2ab07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.category-pill','data' => ['label' => $kategori->nama,'active' => request('kategori') == $kategori->id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.category-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kategori->nama),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('kategori') == $kategori->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3f30a12d951a73db04606714aa2ab07)): ?>
<?php $attributes = $__attributesOriginale3f30a12d951a73db04606714aa2ab07; ?>
<?php unset($__attributesOriginale3f30a12d951a73db04606714aa2ab07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3f30a12d951a73db04606714aa2ab07)): ?>
<?php $component = $__componentOriginale3f30a12d951a73db04606714aa2ab07; ?>
<?php unset($__componentOriginale3f30a12d951a73db04606714aa2ab07); ?>
<?php endif; ?>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal6b9425df5547c9007bd6199cf33985b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b9425df5547c9007bd6199cf33985b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.event-card','data' => ['title' => $event->judul,'date' => $event->tanggal_waktu,'location' => $event->lokasi,'price' => $event->tikets_min_harga,'image' => $event->gambar,'href' => route('events.show', $event)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.event-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->judul),'date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->tanggal_waktu),'location' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->lokasi),'price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->tikets_min_harga),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->gambar),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('events.show', $event))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b9425df5547c9007bd6199cf33985b4)): ?>
<?php $attributes = $__attributesOriginal6b9425df5547c9007bd6199cf33985b4; ?>
<?php unset($__attributesOriginal6b9425df5547c9007bd6199cf33985b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b9425df5547c9007bd6199cf33985b4)): ?>
<?php $component = $__componentOriginal6b9425df5547c9007bd6199cf33985b4; ?>
<?php unset($__componentOriginal6b9425df5547c9007bd6199cf33985b4); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH D:\Semester 7\Ticketing_App-main\resources\views/home.blade.php ENDPATH**/ ?>