 

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Tambah Tipe Tiket</h2>

    <form action="<?php echo e(route('ticket-type.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="nama_tipe_tiket" class="form-label">Nama Tipe Tiket</label>
            <input 
                type="text" 
                name="nama_tipe_tiket" 
                id="nama_tipe_tiket"
                class="form-control"
                placeholder="Contoh: VIP, Reguler"
                required
            >
        </div>

        <button type="submit" class="btn btn-primary">
            Simpan
        </button>

        <a href="<?php echo e(route('ticket-types.index')); ?>" class="btn btn-secondary">
            Kembali
        </a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Semester 7\Bimbingan Karir\Tugas Ticketing app\Ticketing_App-main\resources\views/admin/ticket-type/create.blade.php ENDPATH**/ ?>