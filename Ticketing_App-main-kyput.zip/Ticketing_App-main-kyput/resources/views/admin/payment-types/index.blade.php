<x-layouts.admin title="Manajemen Tipe Pembayaran">

<a href="{{ route('admin.payment-types.create') }}" class="btn btn-primary mb-4">
    Tambah Tipe Pembayaran
</a>

<table class="table w-full">
    <tr>
        <th>No</th>
        <th>Nama Tipe Pembayaran</th>
        <th>Aksi</th>
    </tr>

    @foreach($paymentTypes as $item)
    <tr>
        <td>{{ $loop->iteration }}</td>
        <td>{{ $item->nama_tipe_pembayaran }}</td>
        <td>
            <a href="{{ route('admin.payment-types.edit', $item->id) }}" class="btn btn-info btn-sm">Edit</a>

            <form action="{{ route('admin.payment-types.destroy', $item->id) }}" method="POST" class="inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-error btn-sm" onclick="return confirm('Hapus data?')">
                    Hapus
                </button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

</x-layouts.admin>
