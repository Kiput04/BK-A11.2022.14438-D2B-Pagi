<x-layouts.admin title="Edit Tipe Pembayaran">

    <div class="mb-6">
        <h1 class="text-2xl font-semibold">Edit Tipe Pembayaran</h1>
    </div>

    {{-- Error validation --}}
    @if ($errors->any())
        <div class="alert alert-error mb-4">
            <ul class="list-disc list-inside">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.payment-types.update', $paymentType->id) }}" method="POST" class="max-w-lg">
        @csrf
        @method('PUT')

        <div class="mb-4">
            <label class="label">
                <span class="label-text">Nama Tipe Pembayaran</span>
            </label>
            <input
                type="text"
                name="nama_tipe_pembayaran"
                class="input input-bordered w-full"
                value="{{ old('nama_tipe_pembayaran', $paymentType->nama_tipe_pembayaran) }}"
                required
            >
        </div>

        <div class="flex gap-2">
            <button type="submit" class="btn btn-primary">
                Update
            </button>
            <a href="{{ route('admin.payment-types.index') }}" class="btn btn-secondary">
                Kembali
            </a>
        </div>
    </form>

</x-layouts.admin>
