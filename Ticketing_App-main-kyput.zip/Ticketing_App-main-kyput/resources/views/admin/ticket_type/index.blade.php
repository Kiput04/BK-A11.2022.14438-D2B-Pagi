<x-layouts.admin title="Manajemen Tipe Tiket">

    @if(session('success'))
        <div class="alert alert-success mb-4">{{ session('success') }}</div>
    @endif

    <div class="flex justify-between items-center mb-4">
        <h1 class="text-2xl font-semibold">Manajemen Tipe Tiket</h1>
        <a href="{{ route('admin.ticket-types.create') }}" class="btn btn-primary">Tambah Tipe Tiket</a>
    </div>

    <table class="table w-full">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Tipe Tiket</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($types as $index => $type)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $type->nama_tipe_tiket }}</td>
                    <td>
                        <a href="{{ route('admin.ticket-type.edit', $type->id) }}" class="btn btn-sm btn-info">Edit</a>
                        <form action="{{ route('admin.ticket-type.destroy', $type->id) }}" method="POST" class="inline">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-error" onclick="return confirm('Hapus tipe tiket ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="3" class="text-center">Belum ada tipe tiket.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

</x-layouts.admin>