<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TicketType;

class TicketTypeController extends Controller
{
    public function index()
    {
        $types = TicketType::orderBy('nama_tipe_tiket')->get();
        return view('admin.ticket_type.index', compact('types'));
    }

    public function create()
    {
        return view('admin.ticket_type.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_tipe_tiket' => 'required|string|unique:ticket_type,nama_tipe_tiket',
        ]);

        TicketType::create($validated);

        return redirect()->route('admin.ticket-type.index')
            ->with('success', 'Tipe tiket berhasil ditambahkan.');
    }

    public function edit($ticketType)
    {
        $ticketType = TicketType::findOrFail($ticketType);
        return view('admin.ticket_type.edit', compact('ticketType'));
    }

    public function update(Request $request, TicketType $ticketType)
    {
        $validated = $request->validate([
            'nama_tipe_tiket' => 'required|string|unique:ticket_type,nama_tipe_tiket,' . $ticketType->id,
        ]);

        $ticketType->update($validated);

        return redirect()->route('admin.ticket-type.index')
            ->with('success', 'Tipe tiket berhasil diperbarui.');
    }

    public function destroy(TicketType $ticketType)
    {
        $ticketType->delete();
        return redirect()->route('admin.ticket-type.index')
            ->with('success', 'Tipe tiket berhasil dihapus.');
    }
}