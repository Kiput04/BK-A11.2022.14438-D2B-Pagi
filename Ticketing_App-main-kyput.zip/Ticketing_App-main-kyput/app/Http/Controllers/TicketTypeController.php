<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TicketType;

class TicketTypeController extends Controller
{
    public function index()
    {
        $ticketTypes = TicketType::all();
        return view('ticket_type.index', compact('ticketTypes'));
    }

    public function create()
    {
        return view('ticket_type.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_tipe_tiket' => 'required'
        ]);

        TicketType::create($request->all());
        return redirect()->route('ticket-type.index')->with('success','Data berhasil ditambahkan');
    }

    public function edit($id)
    {
        $ticketType = TicketType::findOrFail($id);
        return view('ticket_type.edit', compact('ticketType'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_tipe_tiket' => 'required'
        ]);

        $ticketType = TicketType::findOrFail($id);
        $ticketType->update($request->all());

        return redirect()->route('ticket-type.index')->with('success','Data berhasil diupdate');
    }

    public function destroy($id)
    {
        TicketType::destroy($id);
        return redirect()->route('ticket-type.index')->with('success','Data berhasil dihapus');
    }
}
